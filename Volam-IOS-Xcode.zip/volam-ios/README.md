# Võ Lâm 2D cho iPhone/iPad (bản iOS của GameBox APK)

Đây là **project Xcode hoàn chỉnh** để build app chơi `https://volam2d.com/play` trên iOS,
làm đúng vai trò như file APK bên Android: mở thẳng vào game, toàn màn hình, có thanh địa chỉ ẩn/hiện.

## Nói thật trước: ở đây KHÔNG tạo ra được file .ipa

File `.ipa` là app iOS **đã ký bằng chứng chỉ Apple**. Việc ký đó bắt buộc phải có:
- macOS + Xcode, và
- Apple ID/Team của bạn (hoặc tài khoản Apple Developer), và
- UDID của iPhone (với chữ ký development).

Máy chủ làm việc này chạy Linux, **không có Xcode**, nên mình không thể biên dịch hay ký `.ipa` ở đây.
Mình đã làm phần làm được: mã nguồn + project mở lên là chạy, kèm script build ra `.ipa` trên Mac.
Nếu bạn muốn **dùng ngay bây giờ mà không cần Mac**, xem cách A bên dưới.

## Cách A — Dùng ngay, không cần Mac (khuyên thử trước)

1. Mở **Safari** trên iPhone (không dùng Chrome).
2. Vào `https://volam2d.com/play`, đăng nhập.
3. Bấm nút **Chia sẻ** → **Thêm vào MH chính** (Add to Home Screen).
4. Mở từ icon vừa thêm: game chạy toàn màn hình như một app.

Đây là PWA của chính trang game; không cần ký, không hết hạn. Nhược điểm: vẫn là Safari,
không có thanh địa chỉ riêng của app và không có các nút Back/Home như app này.

## Cách B — Chạy thử trên iPhone bằng Xcode (miễn phí, cần Mac)

1. Giải nén ZIP, mở `VolamIOS.xcodeproj` bằng Xcode 15 trở lên.
2. Chọn target **VolamIOS** → tab **Signing & Capabilities**:
   - Tick **Automatically manage signing**.
   - **Team**: chọn Apple ID của bạn (thêm ở Xcode → Settings → Accounts nếu chưa có).
   - Nếu báo trùng bundle id, đổi `com.lemoncode.volamios` thành `com.tenban.volamios`.
3. Cắm iPhone, chọn iPhone làm đích chạy, bấm **Run** (⌘R).
4. Lần đầu trên máy: **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** → tin cậy chứng chỉ developer của bạn.

Lưu ý của Apple ID miễn phí: app **hết hạn sau 7 ngày** (chạy lại ⌘R để gia hạn),
tối đa 3 app cài cùng lúc, không xuất bản App Store.

## Cách C — Xuất file .ipa trên Mac

```bash
TEAM_ID=ABCDE12345 ./build-ipa.sh
```

- `TEAM_ID` lấy ở Xcode → Settings → Accounts → Team ID (10 ký tự).
- Kết quả: `build/export/VolamIOS.ipa`.
- Cài lên iPhone: mở Xcode → **Window → Devices and Simulators** → kéo `.ipa` vào,
  hoặc dùng **Apple Configurator**, hoặc **AltStore/Sideloadly** (vẫn phải ký bằng Apple ID của bạn).
- Muốn đưa lên App Store/TestFlight: đổi `method` trong `ExportOptions.plist` thành `app-store`,
  rồi upload bằng Transporter hoặc `xcrun altool`.

## Trong app có gì

- **WKWebView** mở sẵn `https://volam2d.com/play`, giữ đăng nhập bằng cookie/localStorage mặc định.
- **Toàn màn hình**, ẩn thanh trạng thái; xoay ngang/dọc đều được (game tự xin ngang khi vào).
- **Giữ màn hình sáng** khi đang mở app (iOS tự khoá sau ~30 giây nếu không).
- Thanh địa chỉ: Back, Forward, ô địa chỉ (nhập URL bất kỳ), Reload, Home, ẩn thanh (mũi tên).
- **Popup/`window.open`/nút đăng nhập Google** mở bằng Safari, không nạp đè lên trang game.
- **Bắt lỗi JS**: khung đỏ nhỏ hiện lỗi + tệp + dòng ngay trong game (chạm để ẩn) — dùng để báo mình biết hỏng ở đâu.
- **Tiêm `nhap_script.js`** (cùng tệp với bản APK) vào đầu trang, chạy trên mọi trang game.
- Banner lỗi mạng kèm nút **Thử lại** / **Về trang chủ**.
- `NSAllowsArbitraryLoads` bật để không chặn tài nguyên http.

## Giới hạn iOS so với APK (quan trọng)

Android cho phép cửa sổ nổi, chạy nền, nhiều ô game. **iOS không cho**:
- Không có cửa sổ nổi đè lên app khác → **không có bong bóng tròn** như bản 4.6.
- Không chạy tiếp khi ẩn app/tắt màn hình → iOS treo app, WebView dừng.
  Với Võ Lâm 2D, hãy dùng chức năng **treo máy trên máy chủ** của chính game (trang có ghi).
- Không chia nhiều ô game cùng lúc trong một app (mỗi app một WebView; mở nhiều app thì iOS giết bớt).

Nếu bạn cần mấy tính năng đó thì phải dùng bản Android (APK) — đó là giới hạn của hệ điều hành, không phải của app.

## Cấu trúc

```
VolamIOS.xcodeproj/       project Xcode (mở bằng Xcode)
VolamIOS/
  VolamIOSApp.swift       điểm vào app, ép giao diện tối, ẩn thanh trạng thái
  ContentView.swift       WebView + thanh địa chỉ + banner lỗi
  WebModel.swift          WKWebView, tiêm script, bắt lỗi JS, giữ màn hình sáng
  Info.plist              tên app "Võ Lâm 2D", hướng xoay, ATS
  nhap_script.js          script tiêm (giống bản APK)
  Assets.xcassets/        icon 1024x1024 + màu nhấn
ExportOptions.plist       cấu hình xuất .ipa
build-ipa.sh              script build .ipa trên macOS
```

## Đổi nhanh

- **Tên app**: `CFBundleDisplayName` trong `VolamIOS/Info.plist`.
- **Bundle id**: `PRODUCT_BUNDLE_IDENTIFIER` trong `VolamIOS.xcodeproj/project.pbxproj` (2 chỗ Release/Debug).
- **Trang mở đầu**: `WebModel.home` trong `VolamIOS/WebModel.swift`.
- **Icon**: thay `VolamIOS/Assets.xcassets/AppIcon.appiconset/icon-1024.png` (PNG 1024×1024, không alpha).

## Chưa kiểm tra được

Mình **chưa build/chạy được trên Mac hay iPhone thật** (không có Xcode ở đây), nên chưa thể nói app đã chạy.
Phần đã kiểm: cấu trúc project hợp lệ (26 object, ngoặc cân), `Info.plist` và `ExportOptions.plist` đọc được bằng `plistlib`,
icon PNG 1024×1024 tồn tại, `build-ipa.sh` qua `bash -n`. Khi chạy thật mà game không lên, khung đỏ sẽ ghi lỗi —
chụp gửi mình để sửa đúng chỗ.
