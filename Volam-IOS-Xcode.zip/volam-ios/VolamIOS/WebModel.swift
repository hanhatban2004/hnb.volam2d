import SwiftUI
import UIKit
import WebKit

/// Giữ một WKWebView duy nhất cho cả app, kèm tiến trình tải và trạng thái điều hướng.
final class WebModel: NSObject, ObservableObject {
    static let home = "https://volam2d.com/play"

    @Published var progress: Double = 0
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var title = "Võ Lâm 2D"
    @Published var error: String?

    let web: WKWebView
    private var obs: [NSKeyValueObservation] = []

    override init() {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.defaultWebpagePreferences.allowsContentJavaScript = true
        cfg.preferences.javaScriptCanOpenWindowsAutomatically = true
        cfg.websiteDataStore = .default()

        // Bắt lỗi JS ngay từ đầu trang: khung đỏ nhỏ trong game, chạm để ẩn.
        cfg.userContentController.addUserScript(
            WKUserScript(source: WebModel.errorHook, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        // Script quản lý script của bạn (bản iOS dùng chung tệp với APK).
        if let path = Bundle.main.path(forResource: "nhap_script", ofType: "js"),
           let js = try? String(contentsOfFile: path, encoding: .utf8) {
            cfg.userContentController.addUserScript(
                WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        }

        web = WKWebView(frame: .zero, configuration: cfg)
        super.init()

        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.scrollView.bounces = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.04, green: 0.05, blue: 0.07, alpha: 1)

        obs.append(web.observe(\.estimatedProgress, options: [.new]) { [weak self] w, _ in
            DispatchQueue.main.async { self?.progress = w.estimatedProgress }
        })
        obs.append(web.observe(\.canGoBack, options: [.new]) { [weak self] w, _ in
            DispatchQueue.main.async { self?.canGoBack = w.canGoBack }
        })
        obs.append(web.observe(\.canGoForward, options: [.new]) { [weak self] w, _ in
            DispatchQueue.main.async { self?.canGoForward = w.canGoForward }
        })
        obs.append(web.observe(\.title, options: [.new]) { [weak self] w, _ in
            DispatchQueue.main.async { self?.title = w.title ?? "Võ Lâm 2D" }
        })

        load(WebModel.home)
    }

    func load(_ text: String) {
        let raw = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        let fixed = raw.contains("://") ? raw : "https://" + raw
        guard let url = URL(string: fixed) else { return }
        error = nil
        web.load(URLRequest(url: url))
    }

    func reload() {
        error = nil
        web.reload()
    }

    func goBack() { web.goBack() }
    func goForward() { web.goForward() }

    /// Giữ màn hình sáng khi đang chơi (iOS tự khoá màn hình sau ~30 giây nếu không).
    func keepAwake(_ on: Bool) {
        UIApplication.shared.isIdleTimerDisabled = on
    }

    static let errorHook = """
    (function(){
      if(window.__GBERR__){return;}window.__GBERR__=1;
      function show(t){try{
        var d=document.getElementById('__gberr');
        if(!d){d=document.createElement('div');d.id='__gberr';
          d.style.cssText='position:fixed;left:4px;right:4px;bottom:6px;z-index:2147483647;background:#3a0d0d;color:#ffd7d7;font:11px/1.35 monospace;padding:6px 8px;border:1px solid #ff6b6b;border-radius:8px;white-space:pre-wrap;max-height:40%;overflow:auto';
          d.addEventListener('click',function(){d.remove();});
          (document.body||document.documentElement).appendChild(d);}
        d.textContent='\\u26a0 Lỗi JS: '+t+'  (chạm để ẩn)';}catch(e){}}
      window.addEventListener('error',function(e){
        var t=e&&e.target;
        if(t&&t!==window&&t.tagName){show('không tải được '+t.tagName.toLowerCase()+' '+(t.src||t.href||''));}
        else{show(((e&&e.message)||'lỗi')+' @'+String((e&&e.filename)||'').split('/').pop()+':'+((e&&e.lineno)||''));}
      },true);
      window.addEventListener('unhandledrejection',function(e){
        var r=e&&e.reason;show('Promise: '+((r&&(r.message||r))||''));});
    })();
    """
}

extension WebModel: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        progress = 1
        error = nil
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError err: Error) {
        error = err.localizedDescription
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError err: Error) {
        error = err.localizedDescription
    }
}

extension WebModel: WKUIDelegate {
    /// window.open / target=_blank: mở bằng Safari, không nạp đè lên trang game.
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url {
            UIApplication.shared.open(url)
        }
        return nil
    }
}
