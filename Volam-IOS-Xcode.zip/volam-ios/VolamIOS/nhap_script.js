// ==UserScript==
// @name         Võ Lâm 2D – Trình quản lý script (nhập / lưu / xoá)
// @namespace    volam2d-script-mgr
// @version      1.0.3
// @description  Menu nổi để nhập tệp .js (hoặc dán mã), lưu vào trình duyệt, bật/tắt, chạy, sửa, tải về và xoá script ngay trong game.
// @author       Lemon Code
// @match        https://volam2d.com/*
// @match        http://volam2d.com/*
// @match        https://*.volam2d.com/*
// @match        https://tutien.site/*
// @match        http://localhost/*
// @match        http://127.0.0.1/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

/* =============================================================================
 * VÕ LÂM 2D – TRÌNH QUẢN LÝ SCRIPT  v1.0.3
 * -----------------------------------------------------------------------------
 * Script độc lập, không phụ thuộc volam-tron-bo.user.js hay "Gộp BOSS + TS.js".
 *
 * CÁCH DÙNG
 *   - Bấm nút "Script" ở góc dưới-trái (hoặc Alt+S) để mở menu.
 *   - "＋ Nhập tệp": chọn 1 hoặc nhiều tệp .js / .txt (hoặc kéo-thả tệp vào panel).
 *   - "Dán mã": dán trực tiếp mã JavaScript.
 *   - Mỗi script lưu trong localStorage của volam2d.com, có nút BẬT/TẮT để tự chạy khi vào game.
 *   - "Tải" xuất lại đúng nội dung .js; "Sao lưu" xuất cả bộ ra 1 tệp .json.
 *
 * LƯU Ý
 *   - Đây là nơi lưu + chạy script, KHÔNG phải sandbox: script được chèn vào trang
 *     bằng thẻ <script> nên có toàn quyền như code của game.
 *   - Script bật ✔ sẽ chạy lại mỗi lần tải trang (một lần/trang).
 *   - UI tự mount vào #app khi game xoay ngang (#app.rotated) + tự gắn lại nếu bị gỡ khỏi DOM.
 *   - Chữ ký "MOD BY HÀ NHẤT BẢN" ở góc dưới-trái (tắt bằng VLSM.signature(false)).
 *   - Giới hạn: 1,5 MB/script, 4 MB tổng, 100 script (giới hạn localStorage).
 *   - Chỉ dùng 3 khoá lưu: vlsm_scripts_v1, vlsm_pos_v1, vlsm_pill_pos_v1.
 *     Khoá toàn cục: window.__VLSM__ (chống nạp trùng), window.VLSM (API).
 * ========================================================================== */

(function () {
  'use strict';

  if (window.__VLSM__) return;
  window.__VLSM__ = '1.0.0';

  var VERSION = '1.0.3';

  var K_LIST = 'vlsm_scripts_v1';
  var K_POS = 'vlsm_pos_v1';
  var K_PILL = 'vlsm_pill_pos_v1';

  var SIGN_TEXT = 'MOD BY HÀ NHẤT BẢN';

  var MAX_ONE = 1536 * 1024;
  var MAX_ALL = 4096 * 1024;
  var MAX_N = 100;
  var MAX_ERR = 30;

  var state = { list: [], errors: [], ran: {} };
  var ui = {};
  var seq = 0;

  /* ------------------------------------------------------------------ tiện ích */

  function now() { return Date.now(); }

  function genId() {
    seq += 1;
    return 's' + now().toString(36) + seq.toString(36) + Math.floor(Math.random() * 1296).toString(36);
  }

  function fmtSize(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(2) + ' MB';
  }

  function fmtDate(ts) {
    var d = new Date(ts);
    function p(x) { return x < 10 ? '0' + x : '' + x; }
    return p(d.getDate()) + '/' + p(d.getMonth() + 1) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function stamp() {
    var d = new Date();
    function p(x) { return x < 10 ? '0' + x : '' + x; }
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes());
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  function totalSize() {
    var t = 0;
    for (var i = 0; i < state.list.length; i++) t += (state.list[i].code || '').length;
    return t;
  }

  function findById(id) {
    for (var i = 0; i < state.list.length; i++) {
      if (state.list[i].id === id) return state.list[i];
    }
    return null;
  }

  /* ------------------------------------------------------------------ lưu trữ */

  function normalize(raw) {
    if (!raw || typeof raw !== 'object') return null;
    var code = typeof raw.code === 'string' ? raw.code : '';
    if (!code) return null;
    return {
      id: typeof raw.id === 'string' && raw.id ? raw.id : genId(),
      name: String(raw.name || 'script.js').slice(0, 80),
      code: code.slice(0, MAX_ONE),
      enabled: raw.enabled !== false,
      waitGame: raw.waitGame !== false,
      created: typeof raw.created === 'number' ? raw.created : now(),
      updated: typeof raw.updated === 'number' ? raw.updated : now()
    };
  }

  function loadStore() {
    state.list = [];
    var raw = null;
    try { raw = localStorage.getItem(K_LIST); } catch (e) { raw = null; }
    if (!raw) return;
    var arr;
    try { arr = JSON.parse(raw); } catch (e) { return; }
    if (!arr || typeof arr.length !== 'number') return;
    for (var i = 0; i < arr.length && state.list.length < MAX_N; i++) {
      var rec = normalize(arr[i]);
      if (rec) state.list.push(rec);
    }
  }

  function persist() {
    var payload = [];
    for (var i = 0; i < state.list.length; i++) {
      var r = state.list[i];
      payload.push({
        id: r.id, name: r.name, code: r.code,
        enabled: r.enabled, waitGame: r.waitGame,
        created: r.created, updated: r.updated
      });
    }
    try {
      localStorage.setItem(K_LIST, JSON.stringify(payload));
      return true;
    } catch (e) {
      toast('Không lưu được: bộ nhớ trình duyệt đầy (' + fmtSize(totalSize()) + ').', 'bad');
      return false;
    }
  }

  function uniqueName(name, ignoreId) {
    var taken = {}, i;
    for (i = 0; i < state.list.length; i++) {
      if (state.list[i].id !== ignoreId) taken[state.list[i].name] = true;
    }
    if (!taken[name]) return name;

    var base = name, ext = '', dot = name.lastIndexOf('.');
    if (dot > 0 && name.length - dot <= 6) {
      base = name.slice(0, dot);
      ext = name.slice(dot);
    }
    for (i = 2; i < 999; i++) {
      var cand = base + ' (' + i + ')' + ext;
      if (!taken[cand]) return cand;
    }
    return base + ' ' + genId() + ext;
  }

  function addScript(name, code, opts) {
    opts = opts || {};
    code = typeof code === 'string' ? code : String(code == null ? '' : code);
    if (!code.replace(/\s+/g, '')) {
      if (!opts.silent) toast('Nội dung script đang trống.', 'bad');
      return null;
    }
    if (code.length > MAX_ONE) {
      if (!opts.silent) toast('Script quá lớn: ' + fmtSize(code.length) + '.', 'bad');
      return null;
    }
    if (state.list.length >= MAX_N) {
      if (!opts.silent) toast('Đã đạt giới hạn ' + MAX_N + ' script.', 'bad');
      return null;
    }
    if (totalSize() + code.length > MAX_ALL) {
      if (!opts.silent) toast('Tổng dung lượng vượt ' + fmtSize(MAX_ALL) + '.', 'bad');
      return null;
    }

    var clean = String(name || 'script.js').replace(/^.*[\\\/]/, '').slice(0, 80) || 'script.js';
    var rec = {
      id: genId(),
      name: uniqueName(clean),
      code: code,
      enabled: opts.enabled !== false,
      waitGame: opts.waitGame !== false,
      created: now(),
      updated: now()
    };

    state.list.push(rec);
    if (!persist()) {
      state.list.pop();
      return null;
    }
    if (!opts.silent) {
      toast('Đã lưu: ' + rec.name, 'ok');
      render();
    }
    return rec;
  }

  function updateScript(id, patch) {
    var rec = findById(id);
    if (!rec || !patch) return false;
    if (typeof patch.code === 'string') {
      if (!patch.code.replace(/\s+/g, '')) { toast('Nội dung đang trống.', 'bad'); return false; }
      if (patch.code.length > MAX_ONE) { toast('Script quá lớn.', 'bad'); return false; }
      rec.code = patch.code;
    }
    if (typeof patch.name === 'string') {
      var nm = patch.name.replace(/^.*[\\\/]/, '').trim().slice(0, 80);
      if (nm) rec.name = uniqueName(nm, rec.id);
    }
    if (typeof patch.enabled === 'boolean') rec.enabled = patch.enabled;
    if (typeof patch.waitGame === 'boolean') rec.waitGame = patch.waitGame;
    rec.updated = now();
    if (!persist()) return false;
    render();
    return true;
  }

  function removeScript(id) {
    for (var i = 0; i < state.list.length; i++) {
      if (state.list[i].id === id) {
        var name = state.list[i].name;
        state.list.splice(i, 1);
        delete state.ran[id];
        if (!persist()) return false;
        render();
        toast('Đã xoá: ' + name, 'ok');
        return true;
      }
    }
    return false;
  }

  /* ------------------------------------------------------------------ chạy */

  function addError(name, msg) {
    state.errors.unshift({ name: name, msg: msg, at: now() });
    if (state.errors.length > MAX_ERR) state.errors.length = MAX_ERR;
    if (ui.errBadge) {
      ui.errBadge.textContent = String(state.errors.length);
      ui.errBadge.style.display = 'inline-block';
    }
    if (ui.foot) ui.foot.textContent = 'Lỗi gần nhất: ' + name + ' — ' + msg;
  }

  function runScript(rec) {
    if (!rec || !rec.code) return false;
    var host = document.head || document.documentElement;
    if (!host) return false;

    var tag = document.createElement('script');
    tag.setAttribute('data-vlsm', rec.id);
    // sourceURL để lỗi parse/runtime báo đúng script nào (xem onPageError)
    tag.textContent = rec.code + '\n//# sourceURL=vlsm-' + rec.id + '.js\n';
    try {
      host.appendChild(tag);
      host.removeChild(tag);
      state.ran[rec.id] = true;
      try { if (window.console) console.log('[VLSM] chạy ' + rec.name); } catch (e) {}
      return true;
    } catch (e) {
      if (tag.parentNode) tag.parentNode.removeChild(tag);
      addError(rec.name, String((e && e.message) || e));
      toast('Không chạy được ' + rec.name + ': ' + ((e && e.message) || e), 'bad');
      return false;
    }
  }

  function onPageError(ev) {
    var file = String((ev && ev.filename) || '');
    var m = file.match(/vlsm-([a-z0-9]+)\.js/i);
    if (!m) return;
    var rec = findById(m[1]);
    var msg = String((ev && ev.message) || 'Lỗi');
    if (ev && ev.lineno) msg += ' (dòng ' + ev.lineno + ')';
    addError(rec ? rec.name : m[1], msg);
  }

  function waitForGame(cb, timeout) {
    function ready() {
      return !!(document.getElementById('game') || window.G || window.game);
    }
    if (ready()) { cb(); return; }
    var t0 = now();
    var timer = setInterval(function () {
      if (ready() || now() - t0 > timeout) {
        clearInterval(timer);
        cb();
      }
    }, 400);
  }

  function autoRun() {
    var jobs = [], i;
    for (i = 0; i < state.list.length; i++) {
      if (state.list[i].enabled) jobs.push(state.list[i]);
    }
    if (!jobs.length) return;

    function start() {
      for (var j = 0; j < jobs.length; j++) {
        (function (rec) {
          if (rec.waitGame) waitForGame(function () { runScript(rec); }, 30000);
          else runScript(rec);
        })(jobs[j]);
      }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', start, false);
    } else {
      start();
    }
  }

  /* ------------------------------------------------------------------ tệp & tải về */

  function download(fileName, text) {
    try {
      var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      setTimeout(function () {
        if (a.parentNode) a.parentNode.removeChild(a);
        URL.revokeObjectURL(url);
      }, 1500);
      return true;
    } catch (e) {
      toast('Trình duyệt không cho tải tệp.', 'bad');
      return false;
    }
  }

  function readFile(file) {
    if (!file) return;
    if (file.size > MAX_ONE) {
      toast('Tệp quá lớn: ' + file.name + ' (' + fmtSize(file.size) + ').', 'bad');
      return;
    }
    if (!window.FileReader) {
      toast('Trình duyệt không hỗ trợ đọc tệp.', 'bad');
      return;
    }
    var fr = new FileReader();
    fr.onload = function () {
      var text = typeof fr.result === 'string' ? fr.result : '';
      if (/\.json$/i.test(file.name || '')) importBackup(text, file.name);
      else addScript(file.name || 'script.js', text);
    };
    fr.onerror = function () { toast('Không đọc được tệp: ' + file.name, 'bad'); };
    fr.readAsText(file, 'utf-8');
  }

  function handleFiles(files) {
    if (!files || !files.length) return;
    for (var i = 0; i < files.length; i++) readFile(files[i]);
  }

  function backup() {
    if (!state.list.length) { toast('Chưa có script nào để sao lưu.', 'bad'); return; }
    var out = { app: 'vlsm', version: 1, exported: new Date().toISOString(), scripts: [] };
    for (var i = 0; i < state.list.length; i++) {
      var r = state.list[i];
      out.scripts.push({ name: r.name, code: r.code, enabled: r.enabled, waitGame: r.waitGame });
    }
    if (download('vlsm-scripts-' + stamp() + '.json', JSON.stringify(out, null, 2))) {
      toast('Đã xuất ' + state.list.length + ' script ra tệp .json.', 'ok');
    }
  }

  function importBackup(text, fileName) {
    var obj;
    try { obj = JSON.parse(text); } catch (e) {
      toast('Tệp JSON không hợp lệ: ' + fileName, 'bad');
      return;
    }
    var arr = null;
    if (obj && obj.app === 'vlsm' && obj.scripts && typeof obj.scripts.length === 'number') arr = obj.scripts;
    else if (obj && typeof obj.length === 'number') arr = obj;
    if (!arr) { toast('Không nhận ra định dạng sao lưu: ' + fileName, 'bad'); return; }

    var n = 0;
    for (var i = 0; i < arr.length; i++) {
      var it = arr[i] || {};
      if (typeof it.code !== 'string' || !it.code.replace(/\s+/g, '')) continue;
      var got = addScript(it.name || (fileName + ' #' + (i + 1)), it.code, {
        enabled: it.enabled !== false,
        waitGame: it.waitGame !== false,
        silent: true
      });
      if (got) n++;
    }
    render();
    toast(n ? ('Đã nhập ' + n + ' script từ ' + fileName) : 'Tệp không có script hợp lệ.', n ? 'ok' : 'bad');
  }

  /* ------------------------------------------------------------------ CSS */

  var CSS = [
    '.vlsm-pill{position:fixed;left:14px;bottom:14px;z-index:2147483000;display:flex;align-items:center;gap:7px;',
    'padding:9px 14px;border-radius:999px;border:1px solid rgba(240,196,106,.55);cursor:pointer;',
    'background:linear-gradient(180deg,rgba(30,39,56,.97),rgba(13,19,30,.99));color:#f0c46a;',
    'font:600 12.5px/1.2 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;',
    'box-shadow:0 6px 20px rgba(0,0,0,.45);user-select:none;touch-action:manipulation}',
    '.vlsm-pill:active{transform:translateY(1px)}',
    '.vlsm-dot{width:7px;height:7px;border-radius:50%;background:#5fe08a;box-shadow:0 0 8px #5fe08a}',
    '.vlsm-badge{min-width:18px;padding:1px 5px;border-radius:9px;background:rgba(240,196,106,.16);',
    'border:1px solid rgba(240,196,106,.35);font-size:11px;text-align:center;color:#f7dfa5}',

    '.vlsm-panel{position:fixed;z-index:2147483001;display:none;flex-direction:column;',
    'width:min(94vw,430px);max-height:80vh;border-radius:14px;overflow:hidden;',
    'background:linear-gradient(180deg,rgba(22,29,43,.985),rgba(11,16,26,.99));',
    'border:1px solid rgba(120,160,210,.35);box-shadow:0 18px 50px rgba(0,0,0,.6);',
    'color:#e7edf7;font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}',
    '.vlsm-panel *{box-sizing:border-box}',
    '.vlsm-panel.vlsm-open{display:flex}',
    '.vlsm-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;',
    'background:rgba(255,255,255,.04);border-bottom:1px solid rgba(120,160,210,.22);',
    'cursor:move;touch-action:none}',
    '.vlsm-title{font-weight:700;font-size:13px;color:#f7dfa5}',
    '.vlsm-count{display:inline-block;margin-left:4px;padding:0 6px;border-radius:9px;font-size:11px;',
    'background:rgba(240,196,106,.15);border:1px solid rgba(240,196,106,.3);color:#f7dfa5}',
    '.vlsm-errbadge{display:none;margin-left:6px;padding:0 6px;border-radius:9px;font-size:11px;',
    'background:rgba(255,90,90,.16);border:1px solid rgba(255,90,90,.45);color:#ff9d9d}',
    '.vlsm-x{border:0;background:transparent;color:#9aa8be;font-size:15px;cursor:pointer;padding:2px 7px;border-radius:6px}',
    '.vlsm-x:hover{background:rgba(255,255,255,.08);color:#fff}',

    '.vlsm-tools{display:flex;gap:6px;padding:8px 10px;border-bottom:1px solid rgba(120,160,210,.16)}',
    '.vlsm-tb{flex:1;padding:7px 6px;border-radius:8px;cursor:pointer;font:600 11.5px/1.2 system-ui,-apple-system,sans-serif;',
    'border:1px solid rgba(120,160,210,.35);background:rgba(255,255,255,.05);color:#cfdcf0}',
    '.vlsm-tb:hover{background:rgba(120,170,230,.16);border-color:rgba(140,190,245,.55);color:#fff}',
    '.vlsm-tb.vlsm-main{background:linear-gradient(180deg,rgba(240,196,106,.22),rgba(240,196,106,.1));',
    'border-color:rgba(240,196,106,.5);color:#f7dfa5}',

    '.vlsm-bulk{display:flex;align-items:center;gap:10px;padding:0 11px 8px;',
    'border-bottom:1px solid rgba(120,160,210,.12)}',
    '.vlsm-bulk-b{border:0;background:none;padding:2px 0;cursor:pointer;color:#8fb6e6;',
    'font:600 10.5px/1.2 system-ui,-apple-system,sans-serif;text-decoration:underline}',
    '.vlsm-bulk-b:hover{color:#cfe3ff}',
    '.vlsm-bulk-info{margin-left:auto;font-size:10.5px;color:#8c9ab0}',

    '.vlsm-list{flex:1;overflow-y:auto;overflow-x:hidden;padding:6px 8px;min-height:80px;',
    '-webkit-overflow-scrolling:touch}',
    '.vlsm-empty{padding:18px 10px;text-align:center;color:#8c9ab0;font-size:12px;line-height:1.6}',
    '.vlsm-row{border:1px solid rgba(120,160,210,.2);border-radius:10px;background:rgba(255,255,255,.03);',
    'padding:8px 9px;margin-bottom:7px}',
    '.vlsm-rowtop{display:flex;align-items:flex-start;gap:8px}',
    // Nút bật/tắt dùng <div> chứ không dùng <input type=checkbox>: CSS game có
    // "input,select{background:#120d18;border:1px solid;padding:7px 9px}" nên checkbox
    // bị đổi nền tối + phình 34x30px và mất dấu ✔ (người dùng không thấy nút).
    '.vlsm-sw{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;',
    'min-width:48px;height:22px;padding:0 8px;border-radius:11px;cursor:pointer;user-select:none;',
    '-webkit-user-select:none;border:1px solid rgba(255,110,110,.5);background:rgba(255,90,90,.13);',
    'color:#ff9d9d;font:700 10.5px/1 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;',
    'letter-spacing:.4px;white-space:nowrap}',
    '.vlsm-sw:hover{filter:brightness(1.15)}',
    '.vlsm-sw:active{transform:translateY(1px)}',
    '.vlsm-sw.on{border-color:rgba(95,224,138,.55);background:rgba(95,224,138,.15);color:#9df0b8}',
    '.vlsm-sw:focus-visible{outline:2px solid rgba(240,196,106,.7);outline-offset:2px}',
    '.vlsm-name{flex:1;min-width:0}',
    '.vlsm-name-t{font-weight:600;font-size:12.5px;color:#e9f0fb;word-break:break-all}',
    '.vlsm-meta{font-size:10.5px;color:#8c9ab0;margin-top:2px}',
    '.vlsm-acts{display:flex;gap:5px;margin-top:7px;flex-wrap:wrap}',
    '.vlsm-b{flex:1;min-width:52px;padding:5px 4px;border-radius:7px;cursor:pointer;',
    'font:600 11px/1.2 system-ui,-apple-system,sans-serif;border:1px solid rgba(120,160,210,.3);',
    'background:rgba(255,255,255,.05);color:#cfdcf0}',
    '.vlsm-b:hover{background:rgba(120,170,230,.18);color:#fff}',
    '.vlsm-b.vlsm-run{border-color:rgba(95,224,138,.45);color:#9df0b8}',
    '.vlsm-b.vlsm-del{border-color:rgba(255,110,110,.4);color:#ff9d9d}',

    '.vlsm-foot{padding:7px 11px;border-top:1px solid rgba(120,160,210,.18);font-size:10.5px;',
    'color:#8c9ab0;line-height:1.45;max-height:52px;overflow:hidden}',
    '.vlsm-hint{color:#f0c46a}',

    '.vlsm-modal{position:fixed;inset:0;z-index:2147483002;display:flex;align-items:center;justify-content:center;',
    'background:rgba(4,8,14,.62)}',
    '.vlsm-box{width:min(94vw,520px);max-height:88vh;display:flex;flex-direction:column;border-radius:14px;',
    'background:linear-gradient(180deg,rgba(24,32,47,.99),rgba(12,18,28,.99));',
    'border:1px solid rgba(120,160,210,.4);box-shadow:0 20px 60px rgba(0,0,0,.65);color:#e7edf7;',
    'font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;overflow:hidden}',
    '.vlsm-box *{box-sizing:border-box}',
    '.vlsm-bhead{padding:11px 13px;font-weight:700;color:#f7dfa5;font-size:13px;',
    'border-bottom:1px solid rgba(120,160,210,.22);background:rgba(255,255,255,.04)}',
    '.vlsm-bbody{padding:11px 13px;overflow-y:auto}',
    '.vlsm-bfoot{display:flex;gap:7px;padding:10px 13px;border-top:1px solid rgba(120,160,210,.2)}',
    // !important vì CSS game ghi đè mọi "input,select,textarea" (nền tối, viền 2px, padding 7px 9px)
    '.vlsm-box .vlsm-input,.vlsm-box .vlsm-area{width:100%!important;border-radius:8px!important;',
    'border:1px solid rgba(120,160,210,.35)!important;background:rgba(0,0,0,.35)!important;',
    'color:#e7edf7!important;padding:8px 9px!important;box-shadow:none!important;',
    'font:12px/1.4 system-ui,sans-serif;outline:none}',
    '.vlsm-box .vlsm-input:focus,.vlsm-box .vlsm-area:focus{border-color:rgba(240,196,106,.6)!important}',
    '.vlsm-box .vlsm-area{margin-top:7px;min-height:190px;font:11.5px/1.5 ui-monospace,Menlo,Consolas,monospace!important;',
    'resize:vertical;white-space:pre;overflow:auto;tab-size:2}',
    '.vlsm-note{margin-top:7px;font-size:11px;color:#8c9ab0}',
    '.vlsm-btns{flex:1;padding:7px 8px;border-radius:8px;cursor:pointer;',
    'font:600 12px/1.2 system-ui,-apple-system,sans-serif;border:1px solid rgba(120,160,210,.35);',
    'background:rgba(255,255,255,.06);color:#cfdcf0}',
    '.vlsm-btns:hover{background:rgba(120,170,230,.18);color:#fff}',
    '.vlsm-btns.vlsm-ok{background:linear-gradient(180deg,rgba(240,196,106,.26),rgba(240,196,106,.12));',
    'border-color:rgba(240,196,106,.55);color:#f7dfa5}',
    '.vlsm-btns.vlsm-bad{border-color:rgba(255,110,110,.5);color:#ff9d9d}',

    '.vlsm-drop{outline:2px dashed rgba(240,196,106,.75);outline-offset:-6px}',

    // chữ ký góc dưới-trái: nhỏ, vàng gradient, không bắt chuột
    '.vlsm-sign{position:fixed;left:11px;bottom:3px;z-index:2147482998;pointer-events:none;',
    'user-select:none;-webkit-user-select:none;color:#f0c46a;',
    'font:800 9px/1 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;',
    'letter-spacing:1.7px;text-transform:uppercase;white-space:nowrap;opacity:.92;',
    'text-shadow:0 1px 2px rgba(0,0,0,.9),0 0 7px rgba(240,196,106,.35)}',
    '@supports ((-webkit-background-clip:text) or (background-clip:text)){',
    '.vlsm-sign{background:linear-gradient(90deg,#fff3cd 0%,#f0c46a 38%,#b8862c 62%,#f7dfa5 100%);',
    '-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;',
    'color:transparent;text-shadow:none;filter:drop-shadow(0 1px 2px rgba(0,0,0,.85)) drop-shadow(0 0 6px rgba(240,196,106,.3))}}',

    '.vlsm-toasts{position:fixed;z-index:2147483003;right:14px;bottom:14px;display:flex;',
    'flex-direction:column;gap:6px;align-items:flex-end;pointer-events:none}',
    '.vlsm-toast{max-width:min(86vw,340px);padding:8px 11px;border-radius:9px;font:600 11.5px/1.4 system-ui,sans-serif;',
    'background:rgba(18,25,38,.97);border:1px solid rgba(120,160,210,.4);color:#dfe8f5;',
    'box-shadow:0 8px 24px rgba(0,0,0,.5);animation:vlsm-in .16s ease-out}',
    '.vlsm-toast.ok{border-color:rgba(95,224,138,.55);color:#b6f3cb}',
    '.vlsm-toast.bad{border-color:rgba(255,110,110,.55);color:#ffbcbc}',
    '@keyframes vlsm-in{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}'
  ].join('');

  function injectCss() {
    if (document.getElementById('vlsm-style')) return;
    var st = document.createElement('style');
    st.id = 'vlsm-style';
    st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);
  }

  /* ------------------------------------------------------------------ dựng giao diện */

  function buildUI() {
    if (!document.body || ui.panel) return;
    injectCss();

    var pill = el('div', 'vlsm-pill');
    pill.id = 'vlsm-pill';
    pill.title = 'Trình quản lý script (Alt+S)';
    pill.appendChild(el('span', 'vlsm-dot'));
    pill.appendChild(el('span', null, 'Script'));
    var badge = el('span', 'vlsm-badge', '0');
    pill.appendChild(badge);
    pill.addEventListener('click', function () {
      if (pillMoved) { pillMoved = false; return; }
      togglePanel();
    });

    var panel = el('div', 'vlsm-panel');
    panel.id = 'vlsm-panel';

    var head = el('div', 'vlsm-head');
    var title = el('div', 'vlsm-title', 'Script của tôi');
    var count = el('span', 'vlsm-count', '0');
    var errBadge = el('span', 'vlsm-errbadge', '0');
    title.appendChild(count);
    title.appendChild(errBadge);
    var x = el('button', 'vlsm-x', '✕');
    x.title = 'Đóng (Esc)';
    x.addEventListener('click', function () { closePanel(); });
    head.appendChild(title);
    head.appendChild(x);

    var tools = el('div', 'vlsm-tools');
    var bImport = el('button', 'vlsm-tb vlsm-main', '＋ Nhập tệp');
    var bPaste = el('button', 'vlsm-tb', 'Dán mã');
    var bBackup = el('button', 'vlsm-tb', 'Sao lưu');
    bImport.title = 'Chọn tệp .js / .txt / .json trong máy';
    bPaste.title = 'Dán trực tiếp mã JavaScript';
    bBackup.title = 'Xuất toàn bộ script ra 1 tệp .json';
    tools.appendChild(bImport);
    tools.appendChild(bPaste);
    tools.appendChild(bBackup);

    var bulk = el('div', 'vlsm-bulk');
    var bAll = el('button', 'vlsm-bulk-b', 'Bật tất cả');
    var bNone = el('button', 'vlsm-bulk-b', 'Tắt tất cả');
    var bulkInfo = el('span', 'vlsm-bulk-info', '');
    bulk.appendChild(bAll);
    bulk.appendChild(bNone);
    bulk.appendChild(bulkInfo);

    var list = el('div', 'vlsm-list');
    list.id = 'vlsm-list';
    var foot = el('div', 'vlsm-foot');
    foot.appendChild(el('span', 'vlsm-hint', 'Lưu trong trình duyệt này. '));
    foot.appendChild(document.createTextNode('Bấm BẬT để script tự chạy mỗi lần vào game.'));

    panel.appendChild(head);
    panel.appendChild(tools);
    panel.appendChild(bulk);
    panel.appendChild(list);
    panel.appendChild(foot);

    var toasts = el('div', 'vlsm-toasts');
    var fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.accept = '.js,.txt,.json,text/javascript,application/javascript,application/json,text/plain';
    fileInput.style.display = 'none';

    var sign = el('div', 'vlsm-sign', SIGN_TEXT);
    sign.id = 'vlsm-sign';

    document.body.appendChild(pill);
    document.body.appendChild(sign);
    document.body.appendChild(panel);
    document.body.appendChild(toasts);
    document.body.appendChild(fileInput);

    ui = {
      pill: pill, badge: badge, panel: panel, list: list, count: count,
      errBadge: errBadge, foot: foot, toasts: toasts, fileInput: fileInput,
      bulkInfo: bulkInfo, sign: sign
    };

    bImport.addEventListener('click', function () { try { fileInput.click(); } catch (e) {} });
    bPaste.addEventListener('click', function () { openEditor(null); });
    bBackup.addEventListener('click', function () { backup(); });
    bAll.addEventListener('click', function () { setAllEnabled(true); });
    bNone.addEventListener('click', function () { setAllEnabled(false); });

    fileInput.addEventListener('change', function () {
      handleFiles(fileInput.files);
      fileInput.value = '';
    });

    // kéo-thả tệp vào panel
    panel.addEventListener('dragover', function (ev) {
      ev.preventDefault();
      panel.classList.add('vlsm-drop');
    });
    panel.addEventListener('dragleave', function () { panel.classList.remove('vlsm-drop'); });
    panel.addEventListener('drop', function (ev) {
      ev.preventDefault();
      panel.classList.remove('vlsm-drop');
      if (ev.dataTransfer && ev.dataTransfer.files) handleFiles(ev.dataTransfer.files);
    });

    makeDraggable(panel, head);
    makePillDraggable(pill);
    placePill();
    placePanel();
    mountUI();
    window.addEventListener('resize', onViewportChange);
    window.addEventListener('orientationchange', onViewportChange);
    document.addEventListener('fullscreenchange', onViewportChange);
    document.addEventListener('webkitfullscreenchange', onViewportChange);
    watchDom();
    render();
  }

  var pillMoved = false;

  // Game xoay ngang bằng CSS: #app.rotated { transform: rotate(90deg); width: innerHeight; height: innerWidth }
  // Khi đó toạ độ UI phải tính trong hệ của #app, nếu không nút sẽ nằm ngoài vùng nhìn thấy.
  function isRotatedApp() {
    var app = document.getElementById('app');
    return !!(app && app.classList.contains('rotated'));
  }

  function hostSize() {
    if (isRotatedApp()) return { w: window.innerHeight, h: window.innerWidth };
    return { w: window.innerWidth, h: window.innerHeight };
  }

  function hostLocal(x, y) {
    if (!isRotatedApp()) return { x: x, y: y };
    return { x: y, y: window.innerWidth - x };
  }

  function setPillPos(left, top) {
    var pill = ui.pill;
    var w = pill.offsetWidth || 90;
    var h = pill.offsetHeight || 34;
    var hs = hostSize();
    var maxL = Math.max(4, hs.w - w - 4);
    var maxT = Math.max(4, hs.h - h - 4);
    pill.style.left = Math.round(Math.min(Math.max(4, left), maxL)) + 'px';
    pill.style.top = Math.round(Math.min(Math.max(4, top), maxT)) + 'px';
    pill.style.bottom = 'auto';
    pill.style.right = 'auto';
  }

  function placePill() {
    var pos = null;
    try { pos = JSON.parse(localStorage.getItem(K_PILL) || 'null'); } catch (e) { pos = null; }
    if (!ui.pill) return;
    if (pos && typeof pos.left === 'number' && typeof pos.top === 'number') {
      setPillPos(pos.left, pos.top);   // luôn kẹp lại theo màn hình hiện tại
    } else {
      ui.pill.style.left = '';
      ui.pill.style.top = '';
      ui.pill.style.bottom = '';       // mặc định: góc dưới-trái theo CSS
    }
  }

  // ----- Luôn giữ UI trong tầm nhìn -----
  // 1) Game xoay ngang bằng CSS (#app.rotated) -> phải mount vào #app thì UI mới xoay và
  //    toạ độ mới nằm trong vùng nhìn thấy (#app lúc đó rộng innerHeight, cao innerWidth).
  // 2) Game gọi requestFullscreen trên <html> và đổi kích thước khi vào game -> kẹp lại vị trí.
  // 3) Nếu vì lý do nào đó node của UI bị gỡ khỏi DOM -> tự gắn lại.
  function mountHost() {
    var app = document.getElementById('app');
    if (app && app.classList.contains('rotated')) return app;
    return document.body;
  }

  function mountUI() {
    var host = mountHost();
    if (!host) return;
    var nodes = [ui.pill, ui.sign, ui.panel, ui.toasts, ui.fileInput];
    var moved = false;
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i] && nodes[i].parentNode !== host) { host.appendChild(nodes[i]); moved = true; }
    }
    if (moved) {
      placePill();
      if (ui.panel.classList.contains('vlsm-open')) placePanel();
    }
  }

  var reflowT = null;
  function onViewportChange() {
    if (reflowT) clearTimeout(reflowT);
    reflowT = setTimeout(function () {
      reflowT = null;
      mountUI();
      placePill();
      if (ui.panel.classList.contains('vlsm-open')) placePanel();
    }, 120);
  }

  function watchDom() {
    var check = function () {
      if (!ui.pill || !ui.pill.parentNode) { mountUI(); return; }
      if (ui.pill.parentNode !== mountHost()) { mountUI(); return; }
      if (ui.panel && ui.panel.parentNode !== ui.pill.parentNode) { mountUI(); }
    };
    if (window.MutationObserver) {
      var t = null;
      try {
        new MutationObserver(function () {
          if (t) return;
          t = setTimeout(function () { t = null; check(); }, 250);
        }).observe(document.body, { childList: true });
      } catch (e) {}
    }
    setInterval(function () { if (!document.hidden) check(); }, 1500);
  }

  // Bấm = mở/đóng, kéo = dời nút (để không đè lên nút của script khác)
  function makePillDraggable(pill) {
    var downAt = null, moved = false, offX = 0, offY = 0, pid = null;

    function endDrag() {
      downAt = null;
      moved = false;
      pid = null;
    }

    pill.addEventListener('pointerdown', function (ev) {
      if (ev.button != null && ev.button !== 0) return;
      var x = parseInt(pill.style.left, 10);
      var y = parseInt(pill.style.top, 10);
      if (isNaN(x)) x = pill.offsetLeft || 0;
      if (isNaN(y)) y = pill.offsetTop || 0;
      var lp = hostLocal(ev.clientX, ev.clientY);
      downAt = { x: ev.clientX, y: ev.clientY };
      offX = lp.x - x;
      offY = lp.y - y;
      moved = false;
      pid = ev.pointerId;
      try { pill.setPointerCapture(pid); } catch (e) {}
    });

    pill.addEventListener('pointermove', function (ev) {
      if (!downAt) return;
      if (!moved && Math.abs(ev.clientX - downAt.x) + Math.abs(ev.clientY - downAt.y) < 6) return;
      moved = true;
      var p = hostLocal(ev.clientX, ev.clientY);
      setPillPos(p.x - offX, p.y - offY);
      if (ev.preventDefault) ev.preventDefault();
    });

    pill.addEventListener('pointerup', function () {
      if (!downAt) return;
      var wasMoved = moved;
      try { pill.releasePointerCapture(pid); } catch (e) {}
      endDrag();
      if (!wasMoved) return;
      pillMoved = true;
      setTimeout(function () { pillMoved = false; }, 400);
      try {
        localStorage.setItem(K_PILL, JSON.stringify({
          left: parseInt(pill.style.left, 10) || 0,
          top: parseInt(pill.style.top, 10) || 0
        }));
      } catch (e) {}
    });

    pill.addEventListener('pointercancel', endDrag);
  }

  function placePanel() {
    var pos = null;
    try { pos = JSON.parse(localStorage.getItem(K_POS) || 'null'); } catch (e) { pos = null; }
    var p = ui.panel;
    var w = p.offsetWidth || 400;
    var h = p.offsetHeight || 320;
    var hs = hostSize();
    var left = pos && typeof pos.left === 'number' ? pos.left : Math.max(10, (hs.w - w) / 2);
    var top = pos && typeof pos.top === 'number' ? pos.top : Math.max(10, (hs.h - h) / 2 - 20);
    setPanelPos(left, top);
  }

  function setPanelPos(left, top) {
    var p = ui.panel;
    var w = p.offsetWidth || 400;
    var h = p.offsetHeight || 320;
    var hs = hostSize();
    var maxL = Math.max(0, hs.w - w - 6);
    var maxT = Math.max(0, hs.h - Math.min(h, hs.h) - 6);
    left = Math.min(Math.max(6, left), maxL);
    top = Math.min(Math.max(6, top), maxT);
    p.style.left = Math.round(left) + 'px';
    p.style.top = Math.round(top) + 'px';
    p.style.right = 'auto';
    p.style.bottom = 'auto';
  }

  function savePanelPos() {
    try {
      localStorage.setItem(K_POS, JSON.stringify({
        left: parseInt(ui.panel.style.left, 10) || 0,
        top: parseInt(ui.panel.style.top, 10) || 0
      }));
    } catch (e) {}
  }

  function makeDraggable(panel, handle) {
    var dragging = false, id = null, dx = 0, dy = 0;

    function down(ev) {
      if (ev.button != null && ev.button !== 0) return;
      var t = ev.target;
      if (t && t.tagName === 'BUTTON') return;
      dragging = true;
      id = ev.pointerId;
      var lx = parseInt(panel.style.left, 10);
      var ly = parseInt(panel.style.top, 10);
      if (isNaN(lx)) lx = panel.offsetLeft || 0;
      if (isNaN(ly)) ly = panel.offsetTop || 0;
      var lp = hostLocal(ev.clientX, ev.clientY);
      dx = lp.x - lx;
      dy = lp.y - ly;
      try { handle.setPointerCapture(id); } catch (e) {}
      ev.preventDefault();
    }

    function move(ev) {
      if (!dragging || (id != null && ev.pointerId !== id)) return;
      var lp = hostLocal(ev.clientX, ev.clientY);
      setPanelPos(lp.x - dx, lp.y - dy);
    }

    function up(ev) {
      if (!dragging) return;
      dragging = false;
      try { handle.releasePointerCapture(id); } catch (e) {}
      id = null;
      savePanelPos();
      if (ev) ev.preventDefault();
    }

    if (window.PointerEvent) {
      handle.addEventListener('pointerdown', down);
      handle.addEventListener('pointermove', move);
      handle.addEventListener('pointerup', up);
      handle.addEventListener('pointercancel', up);
    } else {
      handle.addEventListener('mousedown', function (ev) {
        down(ev);
        function mm(e) { move(e); }
        function mu(e) { up(e); document.removeEventListener('mousemove', mm); document.removeEventListener('mouseup', mu); }
        document.addEventListener('mousemove', mm);
        document.addEventListener('mouseup', mu);
      });
    }
  }

  function openPanel() {
    if (!ui.panel) return;
    ui.panel.classList.add('vlsm-open');
    placePanel();
    render();
  }

  function closePanel() {
    if (!ui.panel) return;
    ui.panel.classList.remove('vlsm-open');
  }

  function togglePanel() {
    if (!ui.panel) return;
    if (ui.panel.classList.contains('vlsm-open')) closePanel();
    else openPanel();
  }

  /* ------------------------------------------------------------------ danh sách */

  function render() {
    if (!ui.list) return;
    while (ui.list.firstChild) ui.list.removeChild(ui.list.firstChild);
    if (ui.count) ui.count.textContent = String(state.list.length);
    if (ui.badge) ui.badge.textContent = String(state.list.length);

    var onCount = 0;
    for (var k = 0; k < state.list.length; k++) {
      if (state.list[k].enabled !== false) onCount++;
    }
    if (ui.bulkInfo) {
      ui.bulkInfo.textContent = state.list.length
        ? (onCount + '/' + state.list.length + ' đang bật')
        : 'chưa có script';
    }

    if (!state.list.length) {
      var empty = el('div', 'vlsm-empty');
      empty.appendChild(document.createTextNode('Chưa có script nào.'));
      empty.appendChild(document.createElement('br'));
      empty.appendChild(document.createTextNode('Bấm "＋ Nhập tệp" hoặc kéo tệp .js vào đây.'));
      ui.list.appendChild(empty);
      return;
    }
    for (var i = 0; i < state.list.length; i++) ui.list.appendChild(buildRow(state.list[i]));
  }

  function buildRow(rec) {
    var row = el('div', 'vlsm-row');

    var top = el('div', 'vlsm-rowtop');
    var sw = buildSwitch(rec);
    sw.title = 'Bật/tắt tự chạy khi vào game';

    var nameBox = el('div', 'vlsm-name');
    nameBox.appendChild(el('div', 'vlsm-name-t', rec.name));
    nameBox.appendChild(el('div', 'vlsm-meta',
      fmtSize((rec.code || '').length) + ' · ' + fmtDate(rec.updated) +
      (rec.waitGame ? ' · chờ game' : ' · chạy ngay')));

    top.appendChild(sw);
    top.appendChild(nameBox);
    row.appendChild(top);

    var acts = el('div', 'vlsm-acts');
    acts.appendChild(rowBtn('Chạy', 'vlsm-run', function () {
      if (runScript(rec)) toast('Đã chạy: ' + rec.name, 'ok');
    }));
    acts.appendChild(rowBtn('Sửa', '', function () { openEditor(rec); }));
    acts.appendChild(rowBtn('Tải', '', function () {
      download(rec.name.replace(/\.js$/i, '') + '.js', rec.code);
    }));
    acts.appendChild(rowBtn('Xoá', 'vlsm-del', function () { askDelete(rec); }));
    row.appendChild(acts);

    return row;
  }

  function buildSwitch(rec) {
    var on = rec.enabled !== false;
    var sw = el('div', 'vlsm-sw' + (on ? ' on' : ''), on ? 'BẬT' : 'TẮT');
    sw.setAttribute('role', 'switch');
    sw.setAttribute('aria-checked', on ? 'true' : 'false');
    sw.setAttribute('tabindex', '0');

    function toggle() {
      updateScript(rec.id, { enabled: !(rec.enabled !== false) });
    }

    sw.addEventListener('click', function (ev) {
      if (ev && ev.stopPropagation) ev.stopPropagation();
      toggle();
    });
    sw.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
        ev.preventDefault();
        toggle();
      }
    });
    return sw;
  }

  function setAllEnabled(on) {
    if (!state.list.length) return;
    var before = [], i;
    for (i = 0; i < state.list.length; i++) before.push(state.list[i].enabled);
    for (i = 0; i < state.list.length; i++) state.list[i].enabled = on;
    if (!persist()) {
      for (i = 0; i < state.list.length; i++) state.list[i].enabled = before[i];
      render();
      return;
    }
    render();
    toast(on ? 'Đã bật tất cả script.' : 'Đã tắt tất cả script.', 'ok');
  }

  function rowBtn(label, kind, fn) {
    var b = el('button', 'vlsm-b' + (kind ? ' ' + kind : ''), label);
    b.addEventListener('click', function (ev) {
      if (ev && ev.preventDefault) ev.preventDefault();
      if (ev && ev.stopPropagation) ev.stopPropagation();
      fn();
    });
    return b;
  }

  /* ------------------------------------------------------------------ thông báo & hộp thoại */

  function toast(msg, kind) {
    if (!ui.toasts) return;
    var t = el('div', 'vlsm-toast' + (kind === 'ok' ? ' ok' : (kind === 'bad' ? ' bad' : '')), msg);
    ui.toasts.appendChild(t);
    while (ui.toasts.childNodes.length > 4) ui.toasts.removeChild(ui.toasts.firstChild);
    setTimeout(function () {
      if (t.parentNode) t.parentNode.removeChild(t);
    }, 3600);
  }

  var modalStack = [];

  function openModal(title, bodyNode, actions) {
    var wrap = el('div', 'vlsm-modal');
    var box = el('div', 'vlsm-box');
    box.appendChild(el('div', 'vlsm-bhead', title));

    var body = el('div', 'vlsm-bbody');
    body.appendChild(bodyNode);
    box.appendChild(body);

    var foot = el('div', 'vlsm-bfoot');
    var entry = { closed: false };

    function close() {
      if (entry.closed) return;
      entry.closed = true;
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
      var idx = modalStack.indexOf(entry);
      if (idx >= 0) modalStack.splice(idx, 1);
    }
    entry.close = close;

    for (var i = 0; i < actions.length; i++) {
      (function (act) {
        var b = el('button', 'vlsm-btns' + (act.kind ? ' vlsm-' + act.kind : ''), act.label);
        b.addEventListener('click', function () {
          var r = act.fn ? act.fn() : true;
          if (r !== false) close();
        });
        foot.appendChild(b);
      })(actions[i]);
    }
    box.appendChild(foot);
    wrap.appendChild(box);

    wrap.addEventListener('mousedown', function (ev) {
      if (ev.target === wrap) close();
    });

    document.body.appendChild(wrap);
    modalStack.push(entry);

    setTimeout(function () {
      var focusable = box.querySelector('textarea, input');
      if (focusable) {
        try { focusable.focus(); } catch (e) {}
      }
    }, 30);

    return entry;
  }

  function openEditor(rec) {
    var isNew = !rec;
    var box = el('div');

    var nameInput = el('input', 'vlsm-input');
    nameInput.type = 'text';
    nameInput.value = isNew ? '' : rec.name;
    nameInput.placeholder = 'Tên script, vd: auto-nhat.js';

    var ta = el('textarea', 'vlsm-area');
    ta.value = isNew ? '' : rec.code;
    ta.placeholder = 'Dán toàn bộ mã JavaScript ở đây…';
    ta.spellcheck = false;

    var note = el('div', 'vlsm-note',
      'Không cần phần // ==UserScript==. Mã chạy ngay trong trang game nên dùng được mọi biến toàn cục của game.');

    box.appendChild(nameInput);
    box.appendChild(ta);
    box.appendChild(note);

    var actions = [
      {
        label: 'Lưu', kind: 'ok', fn: function () {
          var code = ta.value;
          if (!code.replace(/\s+/g, '')) { toast('Nội dung đang trống.', 'bad'); return false; }
          if (isNew) return !!addScript(nameInput.value || 'script.js', code);
          return updateScript(rec.id, { name: nameInput.value, code: code });
        }
      },
      {
        label: 'Chạy thử', kind: '', fn: function () {
          var code = ta.value;
          if (!code.replace(/\s+/g, '')) { toast('Nội dung đang trống.', 'bad'); return false; }
          var tmp = {
            id: rec ? rec.id : genId(),
            name: (nameInput.value || 'chạy thử') + ' (thử)',
            code: code
          };
          if (!runScript(tmp)) return false;
          toast('Đã chạy thử.', 'ok');
          return false;
        }
      },
      { label: 'Huỷ', kind: '', fn: function () { return true; } }
    ];

    openModal(isNew ? 'Thêm script' : ('Sửa: ' + rec.name), box, actions);
  }

  function askDelete(rec) {
    var box = el('div');
    box.appendChild(el('div', null, 'Xoá "' + rec.name + '" khỏi trình duyệt?'));
    box.appendChild(el('div', 'vlsm-note',
      'Script sẽ bị xoá khỏi localStorage. Muốn giữ bản sao thì bấm "Tải" ở dòng đó trước.'));
    openModal('Xoá script?', box, [
      { label: 'Xoá', kind: 'bad', fn: function () { return removeScript(rec.id); } },
      { label: 'Huỷ', kind: '', fn: function () { return true; } }
    ]);
  }

  function showErrors() {
    var box = el('div');
    if (!state.errors.length) box.appendChild(el('div', null, 'Chưa có lỗi nào.'));
    for (var i = 0; i < state.errors.length; i++) {
      var e = state.errors[i];
      box.appendChild(el('div', 'vlsm-note', fmtDate(e.at) + ' · ' + e.name + ': ' + e.msg));
    }
    openModal('Lỗi script (' + state.errors.length + ')', box, [
      {
        label: 'Xoá danh sách', kind: '', fn: function () {
          state.errors.length = 0;
          if (ui.errBadge) ui.errBadge.style.display = 'none';
          if (ui.foot) ui.foot.textContent = 'Lưu trong trình duyệt này. Bấm BẬT để script tự chạy khi vào game.';
          return true;
        }
      },
      { label: 'Đóng', kind: 'ok', fn: function () { return true; } }
    ]);
  }

  /* ------------------------------------------------------------------ phím tắt & khởi động */

  function onKey(ev) {
    var k = ev.key || '';
    if (k === 'Escape' || k === 'Esc') {
      if (modalStack.length) {
        modalStack[modalStack.length - 1].close();
        ev.preventDefault();
        return;
      }
      if (ui.panel && ui.panel.classList.contains('vlsm-open')) {
        closePanel();
        ev.preventDefault();
      }
      return;
    }
    if ((ev.altKey && (k === 's' || k === 'S')) || k === 'F10') {
      ev.preventDefault();
      togglePanel();
    }
  }

  function init() {
    loadStore();
    buildUI();
    if (ui.errBadge) {
      ui.errBadge.title = 'Xem lỗi của các script đã chạy';
      ui.errBadge.style.cursor = 'pointer';
      ui.errBadge.addEventListener('click', showErrors);
    }
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('error', onPageError, true);
    autoRun();
  }

  window.VLSM = {
    version: VERSION,
    list: function () { return state.list.slice(); },
    errors: function () { return state.errors.slice(); },
    add: function (name, code, opts) {
      var r = addScript(name, code, opts);
      return r ? { id: r.id, name: r.name } : null;
    },
    update: function (id, patch) { return updateScript(id, patch); },
    remove: function (id) { return removeScript(id); },
    run: function (id) { var r = findById(id); return r ? runScript(r) : false; },
    enable: function (id, on) { return updateScript(id, { enabled: !!on }); },
    backup: function () { backup(); },
    importBackup: function (text, fileName) { importBackup(text, fileName || 'backup.json'); },
    importFiles: function (files) { handleFiles(files); },
    resetPos: function () {
      try { localStorage.removeItem(K_PILL); localStorage.removeItem(K_POS); } catch (e) {}
      if (ui.pill) { ui.pill.style.left = ''; ui.pill.style.top = ''; ui.pill.style.bottom = ''; }
      placePill();
      placePanel();
    },
    signature: function (on) {
      if (ui.sign) ui.sign.style.display = on === false ? 'none' : '';
    },
    open: function () { openPanel(); },
    close: function () { closePanel(); },
    toggle: function () { togglePanel(); },
    reload: function () { render(); }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, false);
  } else {
    init();
  }
})();
