import SwiftUI
import UIKit
import WebKit

/// Bọc WKWebView của model thành view của SwiftUI.
struct WebViewBox: UIViewRepresentable {
    let web: WKWebView

    func makeUIView(context: Context) -> WKWebView { web }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ContentView: View {
    @StateObject private var model = WebModel()
    @State private var urlText = WebModel.home
    @State private var barShown = true

    private let bg = Color(red: 0.04, green: 0.05, blue: 0.07)

    var body: some View {
        ZStack(alignment: .top) {
            bg.ignoresSafeArea()
            WebViewBox(web: model.web).ignoresSafeArea()

            if model.progress > 0 && model.progress < 1 {
                ProgressView(value: model.progress)
                    .progressViewStyle(.linear)
                    .tint(.green)
                    .frame(maxWidth: .infinity)
            }

            if barShown {
                bar
            } else {
                Button {
                    barShown = true
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(.green)
                        .padding(8)
                        .background(.black.opacity(0.55))
                        .clipShape(Circle())
                }
                .padding(.top, 6)
                .padding(.trailing, 10)
                .frame(maxWidth: .infinity, alignment: .trailing)
            }

            if let err = model.error {
                errorBanner(err)
            }
        }
        .onAppear { model.keepAwake(true) }
        .onDisappear { model.keepAwake(false) }
    }

    private var bar: some View {
        HStack(spacing: 6) {
            Button { model.goBack() } label: { icon("chevron.left") }
                .disabled(!model.canGoBack)
            Button { model.goForward() } label: { icon("chevron.right") }
                .disabled(!model.canGoForward)

            TextField("Địa chỉ game", text: $urlText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .keyboardType(.URL)
                .submitLabel(.go)
                .onSubmit { model.load(urlText) }
                .font(.system(size: 12))
                .foregroundColor(.white)
                .padding(.horizontal, 8)
                .padding(.vertical, 6)
                .background(Color.white.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 8))

            Button { model.reload() } label: { icon("arrow.clockwise") }
            Button { urlText = WebModel.home; model.load(WebModel.home) } label: { icon("house") }
            Button { barShown = false } label: { icon("chevron.up") }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(.black.opacity(0.72))
    }

    private func icon(_ name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 14, weight: .semibold))
            .foregroundColor(.green)
            .frame(width: 30, height: 30)
    }

    private func errorBanner(_ text: String) -> some View {
        VStack(spacing: 8) {
            Text("Không tải được trang")
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(.white)
            Text(text)
                .font(.system(size: 11))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            HStack(spacing: 10) {
                Button("Thử lại") { model.reload() }
                Button("Về trang chủ") { urlText = WebModel.home; model.load(WebModel.home) }
            }
            .font(.system(size: 12, weight: .semibold))
            .foregroundColor(.green)
        }
        .padding(14)
        .background(Color(red: 0.16, green: 0.05, blue: 0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(20)
        .frame(maxHeight: .infinity, alignment: .center)
    }
}
