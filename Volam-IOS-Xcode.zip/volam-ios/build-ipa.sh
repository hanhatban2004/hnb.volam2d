#!/usr/bin/env bash
# Build file .ipa tren macOS co Xcode. Chay: TEAM_ID=ABCDE12345 ./build-ipa.sh
set -euo pipefail
cd "$(dirname "$0")"

SCHEME="VolamIOS"
ARCHIVE="build/VolamIOS.xcarchive"
EXPORT="build/export"

if [ -z "${TEAM_ID:-}" ]; then
  echo "Thieu TEAM_ID. Vi du: TEAM_ID=ABCDE12345 ./build-ipa.sh"
  echo "Tim Team ID: Xcode > Settings > Accounts > (tai khoan Apple) > Team ID"
  exit 1
fi

rm -rf build
mkdir -p build

xcodebuild \
  -project VolamIOS.xcodeproj \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -archivePath "$ARCHIVE" \
  DEVELOPMENT_TEAM="$TEAM_ID" \
  CODE_SIGN_STYLE=Automatic \
  archive

xcodebuild -exportArchive \
  -archivePath "$ARCHIVE" \
  -exportPath "$EXPORT" \
  -exportOptionsPlist ExportOptions.plist

IPA=$(find "$EXPORT" -name '*.ipa' | head -n 1)
if [ -z "$IPA" ]; then
  echo "Khong thay .ipa trong $EXPORT"
  exit 1
fi
echo "XONG: $IPA"
